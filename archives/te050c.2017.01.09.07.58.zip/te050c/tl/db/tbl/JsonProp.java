package te050c.tl.db.tbl;

import java.io.ObjectInputStream;
import java.lang.reflect.Field;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import te050c.tl.TL;
import te050c.tl.db.DB;
import te050c.tl.Util;
import te050c.tl.Form;
import te050c.tl.json.Parser;

public class JsonProp extends Tbl{//Json.Props
	enum Typ{Int,dbl,str,bool,dt,jsonRef,javaObjectDataStream,clntFunc,srvrFunc;//,file,function,codeJson

 Object load(ResultSet rs){
	final int col=3;try{switch(this){
		case Int:return rs.getInt(col);
		case dbl:return rs.getDouble(col);
		case str:case clntFunc:case srvrFunc:return rs.getString(col);
		case bool:{byte b=rs.getByte(col);return b==0?false:b==1?true:null;}
		case dt:return rs.getDate(col);
		case jsonRef:Long ref=rs.getLong(col);return Util.mapCreate(Jr,ref);
		case javaObjectDataStream:java.sql.Blob b=rs.getBlob(col);
			java.io.ObjectInputStream s=new ObjectInputStream( b.getBinaryStream());
			Object o=s.readObject();s.close();
			return o;
	}}catch(Exception ex){TL.tl().error(ex, "TL.DB.JsonProp.Typ.get");}
	return null;}//get(ResultSet)

		/*
		   int save(PreparedStatement ps,String p,Object v) throws Exception{
			   int x=-1;Typ t=this;try{
			   ps.setString(2, p);
			   ps.setString(3, t.toString());
			   switch(t){
			   case javaObjectDataStream:{
				   java.io.PipedInputStream pi=new PipedInputStream();
				   java.io.ObjectOutputStream s=new java.io.
					   ObjectOutputStream(new PipedOutputStream(pi));
				   s.writeObject(v);s.close();
				   ps.setBinaryStream(4, pi);}break;
			   case bool://ps.setObject(4, v==null?-1: ((Boolean)v).booleanValue() );break;
			   case Int:
			   case dbl:
			   case dt:
			   case str:
			   case jsonRef:
			   default:
					   ps.setObject(4, v);
			   }
			   x=ps.executeUpdate();
			   }catch(Exception ex){
					   TL.tl().error(ex,"TL.DB.Tbl.JsonProp.Typ.save");}
			   return x;
		   }*

		int save(PreparedStatement ps,String p,Object v) throws Exception{
		   int x=-1;Typ t=this;byte[]a=null;ByteBuffer b=null;
		   ps.setString(2, p);
		   ps.setString(3, t.toString());
		   switch(t){
			   case jsonRef:v=v instanceof Map?((Map)v).get(Jr):v;//ps.setObject(4, v);break;
			   case Int:b=ByteBuffer.allocate(8)
					   .putLong(((Number)v).longValue());break;
			   case dbl:b=ByteBuffer.allocate(8)
					   .putDouble(((Number)v).doubleValue());break;
			   case dt:b=ByteBuffer.allocate(8)
					   .putLong(((Date)v).getTime());break;
			   case bool:a=new byte[1];a[0]=(byte)(v==null?
				   -1:((Boolean)v).booleanValue()?1:0);break;
			   case str:a=((String)v).getBytes("utf8");break;
			   case javaObjectDataStream:{
				   java.io.PipedInputStream pi=new PipedInputStream();
				   java.io.ObjectOutputStream s=new java.io.
					   ObjectOutputStream(new PipedOutputStream(pi));
				   s.writeObject(v);s.close();
				   ps.setBinaryStream(4, pi);}break;
		   }//switch
		   if(b!=null)
			   a=b.array();
		   if(a!=null)
			   ps.setBytes(4,a);
		   x=ps.executeUpdate();
		   return x;}

		   Object load(ResultSet rs){
			   final int col=3;try{
			   if(this==javaObjectDataStream){
				   java.sql.Blob b=rs.getBlob(col);
				   ObjectInputStream s=new
					   ObjectInputStream( b.getBinaryStream());
				   Object o=s.readObject();s.close();
				   return o;}
			   byte[]a=rs.getBytes(col);
			   ByteBuffer b=this!=str?ByteBuffer.wrap(a):null;
			   switch(this){
			   case Int:return b.getLong();
			   case dbl:return b.getDouble();
			   case str:return new String(a,"utf8");
			   case bool:return a[0]==0?false:a[0]==1?true:null;
			   case dt:return new Date(b.getLong());
			   case jsonRef:return Util.mapCreate(Jr,b.getLong());
		   }}catch(Exception ex){TL.tl().error(ex, "TL.DB.JsonProp.Typ.get");}
		   return null;
		   }//get(ResultSet)
	   */
 static Typ typ(Object p){
	if(p==null||p instanceof Parser.L || p instanceof Boolean)return bool;
	if(p instanceof String)return str;
	if(p instanceof Number)return p instanceof Double||p instanceof Float?dbl:Int;
	if(p instanceof Date)return dt;
	if(p instanceof Json ||p instanceof JsonProp
	||(p instanceof Map && ((((Map)p).containsKey(Jr))
	||((Map)p).containsKey(Parser.L.jsonRef) ) ))return jsonRef;
	return javaObjectDataStream;}

 } //enum Typ

 @Override public List creationDBTIndices(TL tl){
	return Util.lst(
		Util.lst("int(24) PRIMARY KEY NOT NULL AUTO_INCREMENT"//no
				,"int(18) NOT NULL"//jsonRef
				,"text not null"//path
				,"enum('Int','dbl','str','bool','dt','jsonRef','javaObjectDataStream','clntFunc','srvrFunc') NOT NULL"//typ
				,"blob"//json
		)
		,Util.lst(Util.lst("unique key (",C.jsonRef,Util.lst(C.path,64))
				,Util.lst(C.typ,Util.lst(C.json,64))
				,Util.lst(Util.lst(C.path,64),Util.lst(C.json,64))
		)
	);/*
Create table `jsonHead`(
`jsonRef` int(18) primary key auto_increment,
`parent` int(18) not null,
`proto` int(18) not null,
`meta` text, -- json
Key (`parent`),
Key (`proto`),
);

Create table `JsonProp`(
`no` int(24) primary key auto_increment,
`jsonRef` int(18) not null,
`path` text not null,
`typ` enum( 'Int' , 'dbl' , 'str' , 'bool' , 'dt' , 'jsonRef', ‘javaObjectDataStream’	) not null, --	, ‘file’ ,'function','codeJson','javaMap'
`json` blob ,
Unique ( `jsonRef` , `path`(64) ) ,
key(`typ`,`json`(64)) ,
key( `path`(64) , `typ`,`json`(64) )
);

Create table `log`(
`no` int(27) primary key auto_increment ,
`dt` timestamp not null ,
`proto` int(18) ,
`jsonRef`int(18) ,
`path` text ,
`json` blob ,
`act` enum(‘insert’ ,’update’ ,’delete’ ,’login’ ,’logout’) ,
Key (`proto`,`path`(64),`json`(64)),
key(`dt`),
key(`jsonRef`,`path`(64),`act`)
);
*/}

	@F public Integer no,jsonRef;
	@F public String path;
	@F public Typ typ;
	@F public Object json;

 public Map mv(){return json instanceof Map?(Map)json:asMap();}

 public enum C implements CI{no,jsonRef,path,typ,json;
	@Override public Class<? extends Tbl>cls(){return JsonProp.class;}
	@Override public Class<? extends Form>clss(){return cls();}
	@Override public String text(){return name();}
	@Override public Field f(){return Cols.f(name(), cls());}
	@Override public Tbl tbl(){return Tbl.tbl(cls());}
	@Override public void save(){tbl().save(this);}
	@Override public Object load(){return tbl().load(this);}
	@Override public Object value(){return val(tbl());}
	@Override public Object value(Object v){return val(tbl(),v);}
	@Override public Object val(Form f){return f.v(this);}
	@Override public Object val(Form f,Object v){return f.v(this,v);}
 }//C

 @Override public CI pkc(){return C.no;}
 @Override public Object pkv(){return no;}
 @Override public CI[]columns(){return C.values();}
 public static final String dbtName="jsonProp",Jr=Typ.jsonRef.toString();

 @Override public String getName(){return dbtName;}//public	Ssn(){super(Name);}

 JsonProp(JsonProp p){copy(p);}

 public JsonProp(int jsonRef,Object key,Object value){
		this.jsonRef=jsonRef;path=key.toString();json=value;typ=Typ.typ(value);}

 /**@parameter o is the intermediary json-object
  * @param p is the parts of a qualified name of a property path, seperated by dots
  * @param i is the level-of-depth , index in the p-array*/
 static Object get(Object o,String[]p,int i){
	//if(o instanceof Json){Json m=(Json)o;}
	if(o instanceof Map){Map m=(Map)o;
		String n=p[i];
		o=m.get(n);
		if(i<p.length )//&& !( m instanceof Json)
			o=get(o,p,i+1);
	}else if(o instanceof Object[])
	{int j=Util.parseInt(p[i], -1);
		if(j!=-1){
			Object[]a=(Object[])o;
			o=a[j];
			if(i<p.length)
				o=get(o,p,i+1);
		}
	}else if(o instanceof List)//Collection
	{int j=Util.parseInt(p[i], -1);
		if(j!=-1){
			List a=(List)o;
			o=a.get(j);
			if(i<p.length)
				o=get(o,p,i+1);
		}
	}
	return o;}//get

/**load from dbt-jsonProp all properties, param ref should have a prop "jsonRef"*/
static Map<String,JsonProp> loadProps( Json j//int jsonRef,Map<String,JsonProp>m
){//if(m==null)m=new HashMap<String,JsonProp>();
	JsonProp p=new JsonProp(j.jsonRef,-1,-1),i;
	for (Tbl k:p.query(p.where(C.jsonRef,j.jsonRef))) {
		if(p.path!=null && p.path.indexOf('.')==-1){
			i=new JsonProp(p);//i.copy(j);
			j.props.put(i.path,i);
		}
		else{
			String[]a=p.path.split(".");
			String pn=a[0];
			Object o=j.props.get(pn);
			p.json=set(o,a,p.json,0);
			if(o==null)
				j.props.put(pn,new JsonProp(p));
	}}
	return j.props;
} // loadProps

 /**remark(internal):o is parent*/
 static Object set(Object p,String[]path,Object v,int i){
	Object o=p;
	try{
		String s=path[i];int j=Util.parseInt(s, -1)
			,j1=i+1<path.length?Util.parseInt(path[i+1], -1):-1;
		if(o==null)
			o=j==-1&&j1==-1?Util.mapCreate():Util.lst();
		if(o instanceof Json){
			Json m=(Json)o;
			//TODO: think this case through, then implement this case
		}else
		if(o instanceof Map){Map m=(Map)o;
			if(i==path.length-1)
				m.put(s, v);
			else if(i<path.length){
				o=m.get(s);
				if(o==null)
				{	o=new HashMap();//Util.mapCreate();
					m.put(s,o);}
				o=set(o,path,v,i+1);
			}
		}else if(o instanceof List){List m=(List)o;//TODO: switch List to map in cases j==-1
			if(i==path.length-1)//TODO: check when j==-1 with o instanceof List
				m.set(j, v);
			else if(i<path.length){
				o=m.get(j);
				if(o==null){
					o=j==-1?Util.mapCreate():Util.lst();
					m.set(j,o);}
				o=set(o,path,v,i+1);
			}
		}}catch(Exception ex){
		TL.tl().error(ex,
				"TL.DB.Tbl.JsonProp.set(Object o,String[]path,Object v,int i)"
				, o ,path,v,i);}
	//if(i<path.length)o=set(o,path,v,i+1);
	return o;}

	/**return a list of all(objects :jsonRef) that have a ref to this jsonRef with the param- prop path*/
	static Integer[]allFK(int jsonRef,String prop){
		try {return DB.q1col(Integer.class,
			"select `"+C.jsonRef+"` from `"
			+dbtName+"` where `"+C.json+"`=? and `"
			+C.typ+"`=? and `"+C.path+"`=?"
			, jsonRef , Typ.jsonRef , prop );
		} catch (SQLException ex) {TL.tl().error(ex,"allFK");}
		return null;}

	/**return a list of the Primary keys of all props with jsonRef*/
	static Integer[]propsNo(int jsonRef){
		try {return DB.q1col(Integer.class,
			"select `"+C.no+"` from `"
			+dbtName+"` where `"+C.jsonRef+"`=? "
			, jsonRef	);
		} catch (SQLException ex) {TL.tl().error(ex,"propsNo");}
		return null;}

int countPropNamesStartsWith(String p){
	int c= -1;
	try { c = DB.q1int("select count(*) from `"+dbtName+"` where `"+ C.path+"` like '?*'",-1,p);
	} catch (SQLException e) {
		TL.tl().error(e,"tl.db.tbl.JsonProp.countPropNamesStartsWith"); }
	return c;}

void remOldProps(){//String pathStarts
	try{DB.x("delete from `"+dbtName+"` where `"+C.path+"` like '?*'",path);
	}catch(Exception ex){TL.tl().error(ex,
			"TL.DB.Tbl.JsonProp.remOldProps");}
}//remOldPropsByPathStart


/** load from dbTbl `json` all the properties into Map<String,JsonProp>,
 * where the props are tied by dbtColumn `jsonRef`, param jr (short for jsonRef)
	 if jr is negative , then jr is inited from prop jsonRef in param props, if also not found then NOTHING is processed.

	 //return a formal(general-struct) representation of all the properties in the json-obj/array,

	Motivation: the need when updating from ajax .
		must consider the case when the new ajax json(obj or array) has new props
		, or ,
		old-props that are not mentioned in the new axaj json
	  ,in a nutshell, Structural Change ,javadoc-draft2016.08.17.11.10* /

	void savePropMap(TL tl,String path,Map p,Json j){
		if(j.jsonRef==null)
			jsonRef=j.jsonRef=j.jrmp1();
		try{for(Object k:p.keySet()){
			Object v=p.get(k);
			Typ typ=Typ.typ(v);
			if( v instanceof Map )
			{	int jl=j.jsonRef;//jr(v);
				if(jl==-1)
				savePropMap(tl,path+k+'.',(Map)v,j);
			else saveProp(tl,path+k,Typ.jsonRef,j,j);
			}
			else if(v instanceof List)
				savePropList(tl,path+k+".",(List)v,j);
			else saveProp(tl,path+k,typ,v,j);
		}//for
		}catch(Exception ex){}}//sav

	void savePropList(TL tl,String path,List p,Json j){
		if(jsonRef==null)
			jsonRef=j.jsonRef;//jrn(p);
		int k=0,n=p.size();
		try{for(;k<n;k++){
			Object v=p.get(k);
			Typ typ=Typ.typ(v);
			if( v instanceof Map )
			{	int jl=j.jsonRef;//jr(v);
				if(jl==-1)
					savePropMap(tl
						,path+k+'.'
						,(Map)v
						,j);
				else
					saveProp(tl
						,path+k
						,Typ.jsonRef
						,j
						,j.props);
			}
			else if(v instanceof List)
				savePropList(tl,path+k+".",(List)v,j);
			else saveProp(tl,path+k,typ,v,j.props);
		}//for
		}catch(Exception ex){}}//sav
* /
	static boolean propNotEq(Object a,Object b)
	{if((a==null && b==null)
			|| a==b || (a!=null && a.equals(b)))
		return false;
		if(a==null || b==null )
			return true;
		Class ac=a.getClass(),bc=b.getClass();
		if(ac!=bc)
			return true;
		if(a instanceof Map)
		{	Map am=(Map)a,bm=(Map)b;
			if(am.size()!=bm.size())
				return true;
			for(Object k:am.keySet())
			{Object ax=am.get(k),bx=bm.get(k);
				if(propNotEq(ax,bx))
					return true;
			}
		}//if Map
		if(a instanceof List)
		{List am=(List)a,bm=(List)b;int k=0,n=am.size();
			if(n!=bm.size())
				return true;
			for(;k<n;k++)
			{Object ax=am.get(k),bx=bm.get(k);
				if(propNotEq(ax,bx))
					return true;
			}
		}//if List
		return false;
	}

/*	static final String SqlSv="replace into `"+dbtName
			+"` (`"+C.no+"`,`"+C.jsonRef+"`,`"+
			C.path+"`,`"+C.typ+"`,`"+C.json+"`)values(?,?,?,?,?)";

	JsonProp saveProp(TL tl,String path,Typ t,Object v, Json j ){
		JsonProp p=j.props==null?null:j.props.get(path);
		try{boolean New=p==null||p.no==null;
			if(New){if(p==null){
				p=new JsonProp(-1,path==null?"":path,0);
				if(j.props!=null)
					j.props.put(p.path,p);}
				p.no=DB.q1int("select max(`"+C.no+"`)+1 from `"+dbtName+"`", 1);
			}
			if(New || propNotEq(v,p.json)){//int x=
				DB.x(SqlSv,p.no,p.jsonRef=jsonRef,path,(p.typ=t).toString(),p.json=v);
				Log.log_(tl,Log.Entity.json, p.no, New?Log.Act.New:Log.Act.Update, p.json);
			}
		}catch(Exception ex){tl.error(ex,"TL.DB.Tbl.JsonProp.saveProp:ex:path=",path,": json=",v);}
		return p;}* /

//	public static Object save(Object k,Object v){return save(Json.jrmp1(),k,v);}

//static Object save(Object p,int jr){return save(jr,0,p);}

	static Object save(int jr,Object k,Object v){
		JsonProp j=new JsonProp(jr,k,v);j.typ=Typ.typ(v);
		if(v instanceof Json )//j.typ==Typ.typ(j.jsonRef))
			j.json= ((Json)v).jsonRef;
		try{j.save();}catch(Exception ex){TL.tl().error(ex, "TL.DB.Tbl.JsonProp.save:map,jr");}return v;}
*/
}// class TL$DB$JsonProp
