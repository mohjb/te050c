package te050c.tl.db.tbl;

import java.lang.ref.WeakReference;
import java.lang.reflect.Field;
import java.sql.SQLException;
import java.util.*;

import te050c.tl.TL;
import te050c.tl.db.DB;
import te050c.tl.Util;
import te050c.tl.Form;
import te050c.tl.json.Parser;

/**Json-Head*/
public class Json extends Tbl implements Map{

	@Override public List creationDBTIndices(TL tl){
		return Util.lst(
				Util.lst("int(18) NOT NULL primary key auto_increment"//jsonRef
						,"int(18) not null"//parent
						,"int(18) not null"//proto
						,"text not null"//meta
				)
				,Util.lst(Util.lst(Util.lst(C.parent)
						,Util.lst(C.proto)
				))
		);/*
Create table `json`( #jsonHead
`jsonRef` int(18) primary key auto_increment,
`parent` int(18) not null,
`proto` int(18) not null,
`meta` text, #-- json
Key (`parent`),
Key (`proto`),
);

Create table `Json`( #jsonProp
`no` int(24) primary key auto_increment,
`jsonRef` int(18) not null,
`path` text not null,
`typ` enum( 'Int' , 'dbl' , 'str' , 'bool' , 'dt' , 'jsonRef', ‘javaObjectDataStream’	) not null, --	, ‘file’ ,'function','codeJson','javaMap'
`json` blob ,
Unique ( `jsonRef` , `path`(64) ) ,
key(`typ`,`json`(64)) ,
key( `path`(64) , `typ`,`json`(64) )
);

Create table `log`(
`no` int(27) primary key auto_increment ,
`dt` timestamp not null ,
`proto` int(18) ,
`jsonRef`int(18) ,
`path` text ,
`json` blob ,
`act` enum(‘insert’ ,’update’ ,’delete’ ,’login’ ,’logout’) ,
Key (`proto`,`path`(64),`json`(64)),
key(`dt`),
key(`jsonRef`,`path`(64),`act`)
);
*/}

public static Json root;

static  HashMap<Integer,WeakReference<Json>>cache=new
		HashMap<Integer,WeakReference<Json>>();

	@F public Integer jsonRef,parent,proto;
	@F public Object meta;
boolean autoCommit;
	public Map<String,JsonProp>props=new HashMap<String,JsonProp>();
public boolean isAutoCommit(){return autoCommit;}
public boolean getAutoCommit(){return autoCommit;}
public void setAutoCommit(boolean p){ autoCommit=p;}


Json(int jsonRef){this.jsonRef=jsonRef;}

 public Json(int jsonRef,int parent,int proto,Map meta,Map props){
	this.jsonRef=jsonRef;this.parent=parent;this.proto=proto;this.meta=meta;
	if(props!=null)putAll(props);}

/**
 * Returns the number of key-value mappings in this map.  If the
 * map contains more than <tt>Integer.MAX_VALUE</tt> elements, returns
 * <tt>Integer.MAX_VALUE</tt>.
 *
 * @return the number of key-value mappings in this map
 */
@Override public int size() {
	return props.size();
}

/**
 * Returns <tt>true</tt> if this map contains no key-value mappings.
 *
 * @return <tt>true</tt> if this map contains no key-value mappings
 */
@Override public boolean isEmpty() {
	return props.isEmpty();
}

/**
 * Returns <tt>true</tt> if this map contains a mapping for the specified
 * key.  More formally, returns <tt>true</tt> if and only if
 * this map contains a mapping for a key <tt>k</tt> such that
 * <tt>(key==null ? k==null : key.equals(k))</tt>.  (There can be
 * at most one such mapping.)
 *
 * @param key key whose presence in this map is to be tested
 * @return <tt>true</tt> if this map contains a mapping for the specified
 * key
 * @throws ClassCastException   if the key is of an inappropriate type for
 *                              this map
 *                              (<a href="{@docRoot}/java/util/Collection.html#optional-restrictions">optional</a>)
 * @throws NullPointerException if the specified key is null and this map
 *                              does not permit null keys
 *                              (<a href="{@docRoot}/java/util/Collection.html#optional-restrictions">optional</a>)
 */
@Override public boolean containsKey(Object key) {
	return props.containsKey(key);
}

/**
 * Returns <tt>true</tt> if this map maps one or more keys to the
 * specified value.  More formally, returns <tt>true</tt> if and only if
 * this map contains at least one mapping to a value <tt>v</tt> such that
 * <tt>(value==null ? v==null : value.equals(v))</tt>.  This operation
 * will probably require time linear in the map size for most
 * implementations of the <tt>Map</tt> interface.
 *
 * @param value value whose presence in this map is to be tested
 * @return <tt>true</tt> if this map maps one or more keys to the
 * specified value
 * @throws ClassCastException   if the value is of an inappropriate type for
 *                              this map
 *                              (<a href="{@docRoot}/java/util/Collection.html#optional-restrictions">optional</a>)
 * @throws NullPointerException if the specified value is null and this
 *                              map does not permit null values
 *                              (<a href="{@docRoot}/java/util/Collection.html#optional-restrictions">optional</a>)
 */
@Override public boolean containsValue(Object value) {
	return props.containsValue(value);
}

/**
 * Returns the value to which the specified key is mapped,
 * or {@code null} if this map contains no mapping for the key.
 * <p>
 * <p>More formally, if this map contains a mapping from a key
 * {@code k} to a value {@code v} such that {@code (key==null ? k==null :
 * key.equals(k))}, then this method returns {@code v}; otherwise
 * it returns {@code null}.  (There can be at most one such mapping.)
 * <p>
 * <p>If this map permits null values, then a return value of
 * {@code null} does not <i>necessarily</i> indicate that the map
 * contains no mapping for the key; it's also possible that the map
 * explicitly maps the key to {@code null}.  The {@link #containsKey
 * containsKey} operation may be used to distinguish these two cases.
 *
 * @param key the key whose associated value is to be returned
 * @return the value to which the specified key is mapped, or
 * {@code null} if this map contains no mapping for the key
 * @throws ClassCastException   if the key is of an inappropriate type for
 *                              this map
 *                              (<a href="{@docRoot}/java/util/Collection.html#optional-restrictions">optional</a>)
 * @throws NullPointerException if the specified key is null and this map
 *                              does not permit null keys
 *                              (<a href="{@docRoot}/java/util/Collection.html#optional-restrictions">optional</a>)
 */
@Override public Object get(Object key) {
	return props.get(key);
}

/**
 * Associates the specified value with the specified key in this map
 * (optional operation).  If the map previously contained a mapping for
 * the key, the old value is replaced by the specified value.  (A map
 * <tt>m</tt> is said to contain a mapping for a key <tt>k</tt> if and only
 * if {@link #containsKey(Object) m.containsKey(k)} would return
 * <tt>true</tt>.)
 *
 * @param key   key with which the specified value is to be associated
 * @param value value to be associated with the specified key
 * @return the previous value associated with <tt>key</tt>, or
 * <tt>null</tt> if there was no mapping for <tt>key</tt>.
 * (A <tt>null</tt> return can also indicate that the map
 * previously associated <tt>null</tt> with <tt>key</tt>,
 * if the implementation supports <tt>null</tt> values.)
 * @throws UnsupportedOperationException if the <tt>put</tt> operation
 *                                       is not supported by this map
 * @throws ClassCastException            if the class of the specified key or value
 *                                       prevents it from being stored in this map
 * @throws NullPointerException          if the specified key or value is null
 *                                       and this map does not permit null keys or values
 * @throws IllegalArgumentException      if some property of the specified key
 *                                       or value prevents it from being stored in this map
 */
@Override public Object put(Object key, Object value) {
	if( key== Parser.L.jsonRef || Parser.L.jsonRef.name().equals(key))
		jsonRef=value instanceof Number?
			((Number)value).intValue()
			:Util.parseInt(String.valueOf(value),jsonRef);
	else if( key== C.parent || C.parent.name().equals(key))
		parent=value instanceof Number?
			((Number)value).intValue()
			:Util.parseInt(String.valueOf(value),parent);
	else if( key== C.proto || C.proto.name().equals(key))
		proto=value instanceof Number?
			((Number)value).intValue()
			:Util.parseInt(String.valueOf(value),proto);
	else{JsonProp j=new JsonProp(jsonRef,key,value);
		JsonProp x= props.put(key.toString(),j);
		if (autoCommit)try {
			if (x!=null&&x.no>0)j.no=x.no;
			else{//TODO: check if case remove all sub path props
				String o=select(JsonProp.C.no,Tbl.where(C.jsonRef,jsonRef));
				j.no=Util.parseInt(o,-1);
				if(j.no<1)j.no=j.maxPlus1(JsonProp.C.no);}
			j.save();//no TO DO: Map,List,Array, implemented in
			return x;
	}catch (Exception ex){}}
	return this;}

/**
 * Removes the mapping for a key from this map if it is present
 * (optional operation).   More formally, if this map contains a mapping
 * from key <tt>k</tt> to value <tt>v</tt> such that
 * <code>(key==null ?  k==null : key.equals(k))</code>, that mapping
 * is removed.  (The map can contain at most one such mapping.)
 * <p>
 * <p>Returns the value to which this map previously associated the key,
 * or <tt>null</tt> if the map contained no mapping for the key.
 * <p>
 * <p>If this map permits null values, then a return value of
 * <tt>null</tt> does not <i>necessarily</i> indicate that the map
 * contained no mapping for the key; it's also possible that the map
 * explicitly mapped the key to <tt>null</tt>.
 * <p>
 * <p>The map will not contain a mapping for the specified key once the
 * call returns.
 *
 * @param key key whose mapping is to be removed from the map
 * @return the previous value associated with <tt>key</tt>, or
 * <tt>null</tt> if there was no mapping for <tt>key</tt>.
 * @throws UnsupportedOperationException if the <tt>remove</tt> operation
 *                                       is not supported by this map
 * @throws ClassCastException            if the key is of an inappropriate type for
 *                                       this map
 *                                       (<a href="{@docRoot}/java/util/Collection.html#optional-restrictions">optional</a>)
 * @throws NullPointerException          if the specified key is null and this
 *                                       map does not permit null keys
 *                                       (<a href="{@docRoot}/java/util/Collection.html#optional-restrictions">optional</a>)
 */
@Override public Object remove(Object key) {
	return props.remove(key.toString());}

/**
 * Copies all of the mappings from the specified map to this map
 * (optional operation).  The effect of this call is equivalent to that
 * of calling {@link #put(Object, Object) put(k, v)} on this map once
 * for each mapping from key <tt>k</tt> to value <tt>v</tt> in the
 * specified map.  The behavior of this operation is undefined if the
 * specified map is modified while the operation is in progress.
 *
 * @param m mappings to be stored in this map
 * @throws UnsupportedOperationException if the <tt>putAll</tt> operation
 *                                       is not supported by this map
 * @throws ClassCastException            if the class of a key or value in the
 *                                       specified map prevents it from being stored in this map
 * @throws NullPointerException          if the specified map is null, or if
 *                                       this map does not permit null keys or values, and the
 *                                       specified map contains null keys or values
 * @throws IllegalArgumentException      if some property of a key or value in
 *                                       the specified map prevents it from being stored in this map
 */
@Override public void putAll(Map m) {
	for (Object k:m.keySet()
	     ) put(k,m.get(k));}

/**
 * Removes all of the mappings from this map (optional operation).
 * The map will be empty after this call returns.
 *
 * @throws UnsupportedOperationException if the <tt>clear</tt> operation
 *                                       is not supported by this map
 */
@Override public void clear() {props.clear();}

/**
 * Returns a {@link Set} view of the keys contained in this map.
 * The set is backed by the map, so changes to the map are
 * reflected in the set, and vice-versa.  If the map is modified
 * while an iteration over the set is in progress (except through
 * the iterator's own <tt>remove</tt> operation), the results of
 * the iteration are undefined.  The set supports element removal,
 * which removes the corresponding mapping from the map, via the
 * <tt>Iterator.remove</tt>, <tt>Set.remove</tt>,
 * <tt>removeAll</tt>, <tt>retainAll</tt>, and <tt>clear</tt>
 * operations.  It does not support the <tt>add</tt> or <tt>addAll</tt>
 * operations.
 *
 * @return a set view of the keys contained in this map
 */
@Override public Set keySet() {
	return props.keySet();
}

/**
 * Returns a {@link Collection} view of the values contained in this map.
 * The collection is backed by the map, so changes to the map are
 * reflected in the collection, and vice-versa.  If the map is
 * modified while an iteration over the collection is in progress
 * (except through the iterator's own <tt>remove</tt> operation),
 * the results of the iteration are undefined.  The collection
 * supports element removal, which removes the corresponding
 * mapping from the map, via the <tt>Iterator.remove</tt>,
 * <tt>Collection.remove</tt>, <tt>removeAll</tt>,
 * <tt>retainAll</tt> and <tt>clear</tt> operations.  It does not
 * support the <tt>add</tt> or <tt>addAll</tt> operations.
 *
 * @return a collection view of the values contained in this map
 */
@Override public Collection values() {
	return props.values();
}

/**
 * Returns a {@link Set} view of the mappings contained in this map.
 * The set is backed by the map, so changes to the map are
 * reflected in the set, and vice-versa.  If the map is modified
 * while an iteration over the set is in progress (except through
 * the iterator's own <tt>remove</tt> operation, or through the
 * <tt>setValue</tt> operation on a map entry returned by the
 * iterator) the results of the iteration are undefined.  The set
 * supports element removal, which removes the corresponding
 * mapping from the map, via the <tt>Iterator.remove</tt>,
 * <tt>Set.remove</tt>, <tt>removeAll</tt>, <tt>retainAll</tt> and
 * <tt>clear</tt> operations.  It does not support the
 * <tt>add</tt> or <tt>addAll</tt> operations.
 *
 * @return a set view of the mappings contained in this map
 */
@Override public Set<Entry<String,JsonProp>> entrySet() {
	return props.entrySet();
}

public enum C implements CI{jsonRef,parent,proto,meta;
		@Override public Class<? extends Tbl>cls(){return Json.class;}
		@Override public Class<? extends Form>clss(){return cls();}
		@Override public String text(){return name();}
		@Override public Field f(){return Cols.f(name(), cls());}
		@Override public Tbl tbl(){return Tbl.tbl(cls());}
		@Override public void save(){tbl().save(this);}
		@Override public Object load(){return tbl().load(this);}
		@Override public Object value(){return val(tbl());}
		@Override public Object value(Object v){return val(tbl(),v);}
		@Override public Object val(Form f){return f.v(this);}
		@Override public Object val(Form f,Object v){return f.v(this,v);}
	}//C

	@Override public CI pkc(){return C.jsonRef;}
	@Override public Object pkv(){return jsonRef;}
	@Override public CI[]columns(){return C.values();}
	public static final String dbtName="json",Jr=JsonProp.Typ.jsonRef.toString();

	@Override public String getName(){return dbtName;}//public	Ssn(){super(Name);}

	/**return from the db tbl the max value of jsonRef plus 1 ,javadoc-draft2016.08.17.11.10*/
	static int jrMaxPlus1() throws SQLException{
		int no= DB.q1int("select max(`"+C.jsonRef+"`)+1 from `"+dbtName+"`", 1);//super.maxPlus1(C.jsonRef);
		TL.tl().log("TL.DB.Tbl.Json.jrMaxPlus1=",no);
		return no;}

	/**same as jrMaxPlus1 but the method signature doesnt throw anything ,javadoc-draft2016.08.17.11.10*/
	public static int jrmp1(){try {
		return jrMaxPlus1();}catch (SQLException ex){}
		return 1;}

	/**create an instance and set in the db tbl the name-value pairs ,javadoc-draft 2016.08.17.11.10*/
	public static Json create(Object...p) throws Exception{
		int jr=-1;for(int i=0;i<p.length && jr==-1;i+=2)
			if(C.jsonRef.name().equals(p[i]))
				jr=Util.parseInt(String.valueOf(p[i+1]),-1);
		Json j=jr==-1?new Json(jr):cacheGet(jr);
		if(j==null)j=new Json(jr);
		for(int i=0;i<p.length;i+=2){
			Object k=p[i],v=p[i+1];
			j.put(k,v);
		}
		if(j.jsonRef<0)
			j.jsonRef=jrmp1();//jr(m);
		j.save();j.cacheSet();
		return j;}

/*/Json add(Object...p){return this;}Json Add(Object[]p){return this;}
 /**fetch from dbt-Json-head the primary-keys/jsonRef of rows that have this.jsonRef as proto ; javadoc-draft:2017.01.06* /
public List<Json>loadProtoChain(){
	List<Json>chain=new LinkedList<Json>();
	Json t=this,p=t;int jr;
	do {chain.add(t=p);jr=t.jsonRef;
		p=Json.load(jr);
	}while(p!=null&& p.jsonRef>0 && t.jsonRef!=p.jsonRef);//&& p.jsonRef!=-1 && p.jsonRef!=0
	if(p!=null && t!=p && p.jsonRef==0)
		chain.add(p);
	return chain;}
*/

 /**fetch from dbt-Json-head the primary-keys/jsonRef of rows that have this.jsonRef as parent ; javadoc-draft:2017.01.06*/
 public Integer[]loadChildren(){try{Integer[]a= column(C.jsonRef,Integer.class,C.parent,jsonRef);
	return a;}catch(SQLException ex){TL.tl().error(ex,"tl.db.Tbl.Json.loadChildren");}return null;}

 /**fetch from dbt-Json-head the primary-keys/jsonRef of rows that have this.jsonRef as proto ; javadoc-draft:2017.01.06*/
 public Integer[]loadSubProtos(){try{Integer[]a= column(C.jsonRef,Integer.class,C.proto,jsonRef);
	return a;}catch(SQLException ex){TL.tl().error(ex,"tl.db.Tbl.Json.loadSubProtos");}return null;}

 static Json cacheGet(int jr){
	Json j=null;synchronized(cache){
		WeakReference<Json>w=cache.get(jr);
		if(w!=null)
			j=w.get();
	}return j;}

 void cacheSet(){
	synchronized(cache){
		WeakReference<Json>w=new
		WeakReference<Json>(this);
		cache.put(jsonRef,w);}}

 public static Json load(int jr){
	Json j=cacheGet(jr);
	if(j==null) {
		j=new Json(jr);
		j.load();//j.props=JsonProp.loadProps(j);//jr,j.props);
	}return j;}

 @Override public Tbl load(){
	int c=0;try {c=super.count(where(C.jsonRef,jsonRef));}
	catch (Exception e) {TL.tl().error(e,"tl.db.tbl.Json.load:count jsonRef");}
	if(c<1){
		jsonRef=jsonRef<1?jsonRef:-jsonRef;return this;}
	super.load();
 	JsonProp.loadProps(this);
 	return this;}

	/** as can be clearly read from the source-code of the method body
	 , overwrites the super-class method. */
	@Override public Tbl save() throws Exception{
		for (JsonProp j:props.values())
			j.save();
		return super.save();}

 public Json loadProto(){
	int jr=proto;
	if(jr==jsonRef)return this;
	Json p=Json.load(jr);
	return p;}

 public Json loadParent(){
	int jr=parent;
	if(jr==jsonRef)return this;
	Json p=Json.load(jr);
	return p;}

 public Object getUsingChain(String p){
	String[]a=p==null?null:p.split(".");
	return a==null?null:getUsingChain(a);}

 public Object getUsingChain(String[]a){
	//String pn=a==null||a.length<1?null:a[0];
	Object o=//props.get(pn);if(o==null)o=
		JsonProp.get(props,a,0);
	if(o==null){
		Json x=loadProto();
		o=x.getUsingChain(a);
		//if(o==null)o=loadParent().getUsingChain(a);
	}
	return o;
}
}// class TL$DB$Json //Head
