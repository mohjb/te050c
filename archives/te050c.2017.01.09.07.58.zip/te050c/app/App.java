package te050c.app;
import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.jsp.JspWriter;

import te050c.tl.TL;
import te050c.tl.Util;
//import te050c.tl.db.DB;
import te050c.tl.db.tbl.*;

public class App {
 enum UsrLvl{suspended,view,edit,admin}

	static Usr usr(Object uid){
		Usr u=new Usr();
		u.load(uid);return u;}


	static final String SsnNm="TE050c.App"
			,UploadPth="/te050cUploads/";

	//Prm.Screen screen;
	UsrLvl usrLvl=UsrLvl.suspended;

	//Html jsp;

	public static App app(){return app(TL.tl());}
	public static App app(TL tl){
		Object o=tl.s(SsnNm);
		if(o==null)
			tl.s(SsnNm,o=new App());
		App e=(App)o;//e.tl=tl;
		if(tl.usr==null && tl.a(SsnNm+".checkDBTCreation")==null
				){//e.h.checkDBTCreation(tl);
			new H(null).checkDBTCreation(tl);
			new Income().checkDBTCreation(tl);
			new Expense().checkDBTCreation(tl);
			new Json().checkDBTCreation(tl);
			new JsonProp(0,0,0).checkDBTCreation(tl);
			new Usr ().checkDBTCreation(tl);
			new te050c.tl.db.tbl.Ssn().checkDBTCreation(tl);
			new Log().checkDBTCreation(tl);
			tl.a(SsnNm+".checkDBTCreation",tl.now);
		}return e;}

	/**path to the uploaded files for Sheet (the sheet stored in the session)*/
	public String getUploadPath(TL tl){
		//readVars(tl);//if(proj.no!=sheet.p)proj.no=sheet.p;

		return UploadPth//+proj.no+'/'+bld.no+'/'+flr.no+'/'+sheet.no+'/'
				//+sheet.p+'/'+sheet.b+'/'+sheet.f+'/'+sheet.no
		+'/';}


//** * request-parameters:tbl,pk ; or, sql,prm=json* */void doRest(TL tl){}

 void init(Op op) throws Exception{TL tl=TL.tl();
	if(tl.usr==null&&op==Op.login)
	{tl.logo("index:4:login");
		Usr u=Usr.login();tl.logo("index:5:login");
		if(u!=null){u.onLogin();
			Object ul=u.json.get("UsrLvl");
			try{if(ul!=null)usrLvl=UsrLvl.valueOf(ul.toString());}catch(Exception ex){}
			Log.log(Log.Entity.usr
				, tl.usr.uid
				, Log.Act.Login
				,Util.mapCreate("usr",tl.usr,"request",tl.req));
		}else// msg="incorrect login";
			Log.log(Log.Entity.usr
				, tl.usr.uid, Log.Act.Log
				,Util.mapCreate("msg","incorrect login","request",tl.req));
		//tl.logo("index:6:login:msg=",msg);
	}
	if(tl.usr==null && tl.getSession().isNew())
		Log.log(Log.Entity.ssn, -1, Log.Act.Log,
			Util.mapCreate("msg","new Connection","request",tl.req));

	if(tl.usr!=null&&op==Op.logout)
	{ Log.log(Log.Entity.usr, tl.usr.uid
			, Log.Act.Logout
			,Util.mapCreate("usr",tl.usr));
		tl.ssn.onLogout();}

	if(tl.usr==null){try{
		tl.o("<script>location=\"flat-login-form/index.html\"</script>");//TODO: design and implement login html
	}catch(Exception x){tl.error(x,"te050c.App.init2");}
		tl.logo("index:8:end");
		return;
	}tl.logo("index:9");
 }//init

 Json initProtoRoot(){if(Json.root==null){
 	Json.root=Json.load(0);
	Object o=Json.root.get("projects");
	int x=o instanceof Number?((Number)o).intValue():-1;
	if(x>0) {String[]a={"proto","ids","pages","hComp"};
		Json.root.put("projects", Json.load(x));
	}}return Json.root;}//initProtoRoot

/**param is propterty name in Json.root / parent-project */
 Json initProtoProject(String propName){
	Json root=initProtoRoot(),proj=null;
	Object o=root.get(propName);
	if(o instanceof Number){
		int jr=((Number) o).intValue();
		proj=initProtoProject(jr);
	}else proj=(Json)o;
	return proj;}

 Json initProtoProject(int jr){
	Json proj=Json.load(jr);
	if(proj!=null) {
	 String[]a={"proto","ids","pages","hComp"};
	 for (int i = 0; i <a.length ; i++) {
		Object o=proj.get(a[i]);
		int x=o instanceof Number?((Number)o).intValue():-1;
		if(x>0)proj.put(a[i], Json.load(x));
	}}return proj;}//initProject

 /*TODO: implement prototype project
    functions
 void initProtos(Json Proj){}
 void initProjectIds(Json proj){}
 void initPages(Json Proj){}
 void initComps(Json Proj){}//Comp==Html-Components*/

public static void jsp
 (HttpServletRequest request
	,HttpServletResponse response
	,javax.servlet.http.HttpSession session
	,JspWriter out
	,javax.servlet.jsp.PageContext pageContext)
 throws IOException, javax.servlet.ServletException
 {TL tl=null;try
  {tl=TL.Enter(request,out);
	Op op=tl.req("op",Op.none);tl.logo("index:1:",op);
	//response.setContentType("text/html; charset=UTF-8");
	tl.logOut=tl.var("logOut",false);
	App e=App.app(tl);//.init(tl);
	e.init(op);
	if(e.usrLvl==UsrLvl.suspended){
		tl.o("User suspended, please contact System-Admin");
		return;}
	if(tl.json instanceof List){
		for (Object o:(List)tl.json ) {
			if(o instanceof Map){
				Map prm=(Map)o;
				Object x=prm.get("op");
				Op o2=null;
				try{o2=Op.valueOf(String.valueOf(x));}
				catch(Exception ex){}
				if(o2!=null && o2!=Op.none)
					o2.doOp(tl,e,prm);
			}
		}
		tl.response.put("return",tl.json);
	}
	else if(op!=Op.none)
		op.doOp(tl,e,tl.json);//e.doOp(tl,op);
  }
  catch(Exception x){
	if(tl!=null)
		tl.error(x,"/te050c/index.jsp:");
	else
		x.printStackTrace();}
  finally{try{
		List l=tl!=null && tl.response!=null?(
				List)tl.response.get(te050c.tl.db.ItTbl.ErrorsList):null;
		if(l!=null)//errors from DB.ItTbl iterator
			tl.o("<!--",l,"-->");
	}catch(Exception ex){}
		TL.Exit();
  }
	out.write("</body></html>");
 }//jsp

enum Op{none,login,logout
	,projNew{@Override void doOp(TL tl,App app,Map prms){
		//
		}}
	,projEdit//{@Override void doOp(TL tl,App app,Map prms){}}
	,projDelete//{@Override void doOp(TL tl,App app,Map prms){}}
	,projDuplicate//{@Override void doOp(TL tl,App app,Map prms){}}
	,pageNew//{@Override void doOp(TL tl,App app,Map prms){}}
	,pageEdit//{@Override void doOp(TL tl,App app,Map prms){}}
	,pageDelete//{@Override void doOp(TL tl,App app,Map prms){}}
	,pageDuplicate//{@Override void doOp(TL tl,App app,Map prms){}}
	,htmlNew//{@Override void doOp(TL tl,App app,Map prms){}}
	,htmlEdit//{@Override void doOp(TL tl,App app,Map prms){}}
	,htmlDelete//{@Override void doOp(TL tl,App app,Map prms){}}
	,htmlDuplicate//{@Override void doOp(TL tl,App app,Map prms){}}
	,projLoad//{@Override void doOp(TL tl,App app,Map prms){}}
	,pageLoad//{@Override void doOp(TL tl,App app,Map prms){}}
	,htmlLoad//{@Override void doOp(TL tl,App app,Map prms){}}
	//,appOp//{@Override void doOp(TL tl,App app,Map prms){}}
	,jsonPropSrvrJS//params:jsonRef,propNo,arguments
	,jsonHeadNew{@Override void doOp(TL tl,App app,Map prms){
		//params:reqNo,parent-jsonRef,proto-jsonRef, meta,props
		Object reqNo=prms.get("reqNo")
			,prnt=prms.get("parent")
			,proto=prms.get("proto")
			,meta =prms.get("meta")
			,props=prms.get("props");
		int jr=Json.jrmp1();
		Json x=new Json(jr,((Number)prnt) . intValue(),((Number)proto). intValue(),(Map)meta,(Map)props);
		prms.put("return",x);}}//Util.mapSet(tl.response,"return",prms);
	,jsonHeadEdit{@Override void doOp(TL tl,App app,Map prms){
		//params:jsonRef ,parent-jsonRef,proto-jsonRef, ,meta,props
		Object o=prms.get("jsonRef");
		int jr=o instanceof Number?((Number) o).intValue():-1;
		if(jr>0){Object prnt=prms.get("parent")
				,proto=prms.get("proto")
				,meta =prms.get("meta")
				,props=prms.get("props");
			Json x=Json.load(jr);
			prms.put("return",x);
			x.parent=((Number)prnt). intValue();
			x.proto=((Number)proto). intValue();
			x.meta=meta;
			x.putAll((Map)props);}}}
	,jsonHeadDelete{@Override void doOp(TL tl,App app,Map prms){//params:jsonRef
		Object o=prms.get("jsonRef");
		int jr=o instanceof Number?((Number) o).intValue():-1;
		if(jr>0){
			Json x=Json.load(jr);

			prms.put("return",x);}}}
	,jsonPropNew//params:jsonRef,jsonValue
	,jsonPropEdit//params:no ,jsonValue
	,jsonPropDelete//params:no
	,jsonLoad{@Override void doOp(TL tl,App app,Map prms){//params:jsonRef
		Object o=prms.get("jsonRef");
		int jr=o instanceof Number?((Number) o).intValue():-1;
		if(jr>0){
			 Json x=Json.load(jr);
			 prms.put("return",x);}}}
	//,jsonChildren//params:jsonRef   ,jsonTree//params:jsonRef
	;

	void doOp(TL tl,App app,Map params){params.put("msg","op not implemented");}

}//enum Op

}//class App